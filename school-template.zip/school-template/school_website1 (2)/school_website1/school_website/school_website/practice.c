#include <stdio.h>
#include <string.h>

int main() {
   printf("%d", strlen("123456"));
   return 0;

   
}
